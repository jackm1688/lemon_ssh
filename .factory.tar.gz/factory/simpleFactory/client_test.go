package simpleFactory
import (
	"fmt"
	"testing"
)
//调用者
func TestCar(t *testing.T){

	var c1 Car
	var c2 Car

	c1 = MakeCar("audi")
	c2 = MakeCar("byd")

	c1.Run()
	c2.Run()

	fmt.Println("-----------------------")

	c1 = AudiCar()
	c2 = BydCar()

	c1.Run()
	c2.Run()
}
