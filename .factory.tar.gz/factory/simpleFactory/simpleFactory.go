package simpleFactory

import "fmt"

//接口设计
type Car interface {
	Run();
}

//产品结构1
type Audi struct {

}

//产品结构2
type Byd struct{

}

//接口实现
func (this *Audi) Run(){
	fmt.Println("奥迪再奔跑")
}

//接口实现
func (this *Byd) Run(){
	fmt.Println("比亚迪再奔跑")
}

func  MakeCar(ctype string) Car{
	switch ctype {
	case "audi":
		return &Audi{}
	case "byd":
		return &Byd{}
	default:
		return nil
	}
}

func AudiCar() Car{
	return &Audi{}
}

func BydCar() Car{
	return &Byd{}
}

