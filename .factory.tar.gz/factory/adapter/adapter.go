package adapter

import "fmt"

type PSKeyword struct {

}

func NewPSKeyword() *PSKeyword  {
	return &PSKeyword{}
}

func (ps *PSKeyword) Print()  {
     for i:='a'; i <= 'z'; i++{
		 fmt.Printf("%c ",i)
	 }
	 fmt.Println()
}

type IUsb interface {
	HandlePrint()
}

type UsbKeyword struct {
	 Keyword *PSKeyword
}

func NewUsbKeyword(ps *PSKeyword) *UsbKeyword  {
	return &UsbKeyword{Keyword: ps}
}

func (u *UsbKeyword) HandlePrint()  {
	u.Keyword.Print()
}

type MacBook struct {

}

func NewMacBook() *MacBook {
	return &MacBook{}
}

func (m *MacBook)Print(usb IUsb)  {
	usb.HandlePrint()
}