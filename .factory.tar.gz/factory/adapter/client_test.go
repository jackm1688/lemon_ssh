package adapter

import(
	"testing"
)

func TestPrint(t *testing.T)  {
	mackBook := NewMacBook()
	psKeyword := NewPSKeyword()
	usbKeyword := NewUsbKeyword(psKeyword)
	mackBook.Print(usbKeyword)
}
