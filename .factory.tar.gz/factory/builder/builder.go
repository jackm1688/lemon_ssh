package builder

import "fmt"

//引擎
type Engine struct {
	Name string
}

//逃逸塔
type EscapeTower struct{
	Name string
}

//轨道仓
type OrbitalModule struct {
	Name string
}

type AirShip struct{
	Engine *Engine
	EscapeTower *EscapeTower
	OrbitalModule *OrbitalModule
}

func (a *AirShip) Lunch()  {
	fmt.Printf("[1]-loading:%s\n",a.Engine.Name)
	fmt.Printf("[2]-loading:%s\n",a.EscapeTower.Name)
	fmt.Printf("[3]-loading:%s\n",a.OrbitalModule.Name)

	fmt.Printf("\n ----启动火箭-----\n")
}

type AirShipBuilder interface {
	BuildEngine() *Engine
	BuildEscapeTower() *EscapeTower
	BuildOrbitalModule() *OrbitalModule
}

type LemonAirShipBuilder struct {

}

func (l *LemonAirShipBuilder) BuildEngine() *Engine{
	return &Engine{Name: "柠檬高级发动机"}
}

func (l *LemonAirShipBuilder) BuildEscapeTower() *EscapeTower{
	return &EscapeTower{Name: "柠檬高级逃逸塔"}
}

func (l *LemonAirShipBuilder) BuildOrbitalModule() *OrbitalModule{
	return &OrbitalModule{Name: "柠檬高级轨道仓"}
}


type AirShipDirectory interface {
	DirectoryAirShip() *AirShip
}

type LemonAirShipDirectory struct {
	Builder AirShipBuilder
}

func (l *LemonAirShipDirectory) DirectoryAirShip() *AirShip  {
	airShip := &AirShip{}
	airShip.Engine = l.Builder.BuildEngine()
	airShip.OrbitalModule = l.Builder.BuildOrbitalModule()
	airShip.EscapeTower = l.Builder.BuildEscapeTower()
	return  airShip

}


