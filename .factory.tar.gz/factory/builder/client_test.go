	package builder

	import "testing"

	func Test_Builder(t *testing.T)  {

		var directory AirShipDirectory
		var builder AirShipBuilder
		builder = &LemonAirShipBuilder{}
		directory = &LemonAirShipDirectory{Builder:builder }

		ship := directory.DirectoryAirShip()
		ship.Lunch()
	}
