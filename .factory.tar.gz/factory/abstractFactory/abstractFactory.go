package abstractFactory

import "fmt"

type Engine interface {
	Run()
	Start()
}

type LuxuryEngine struct{}

type LowEngine struct{}

func (this *LuxuryEngine) Run(){
	fmt.Println("百米加速秒级")
}

func (this *LuxuryEngine) Start(){
	fmt.Println("启动fast")
}

func (this *LowEngine) Run(){
	fmt.Println("百米加速分钟级")
}

func (this *LowEngine) Start(){
	fmt.Println("启动slow")
}

type Seat interface {
	Message()
}

type LuxurySeat struct {}

type LowSeat struct{}

func (this *LuxurySeat) Message(){
	fmt.Println("自动按摩")
}

func (this *LowSeat) Message(){
	fmt.Println("不支持自动按摩")
}

type Tyre interface {
	Revolution()
}

type LuxuryTyre struct{}

type LowTyre struct{}

func (this *LuxuryTyre) Revolution(){
	fmt.Println("转速:7200/s")
}

func (this *LowTyre) Revolution(){
	fmt.Println("转速:5400/s")
}

type CarFactory interface {
	CreateEngine() Engine
	CreateSeat() Seat
	CreateTyre() Tyre
}

type LuxuryCarFactory struct {}
type LowCarFactory struct {}

func (this *LuxuryCarFactory) CreateEngine() Engine{
	return &LuxuryEngine{}
}

func (this *LuxuryCarFactory) CreateSeat() Seat{
	return &LuxurySeat{}
}

func (this *LuxuryCarFactory) CreateTyre() Tyre{
	return &LuxuryTyre{}
}


//--

func (this *LowCarFactory) CreateEngine() Engine{
	return &LowEngine{}
}

func (this *LowCarFactory) CreateSeat() Seat{
	return &LowSeat{}
}

func (this *LowCarFactory) CreateTyre() Tyre{
	return &LowTyre{}
}