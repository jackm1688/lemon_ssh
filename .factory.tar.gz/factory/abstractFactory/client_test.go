package abstractFactory

import(
	"testing"
)

func TestLowCarFactory(t *testing.T) {

	var car CarFactory = &LuxuryCarFactory{}
	var engine Engine = car.CreateEngine()
	engine.Start()
	engine.Run()
}
