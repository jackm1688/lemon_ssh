package staticProxy

import "fmt"

type Star interface {
	//面谈
	Confer()
	//签合同
	SignContract()
	//订票
	BookTicket()
	//唱歌
	Sing()
	//收钱
	CollectMoney()
}

type RealStar struct {
	Name string
}

func NewRealStar(name string) Star {
	return &RealStar{Name: name}
}



//面谈
func (this *RealStar)Confer(){
	fmt.Printf("%s---->面谈\n",this.Name)
}

//签合同
func (this *RealStar)SignContract(){
	fmt.Printf("%s---->签合同\n",this.Name)
}

//订票
func (this *RealStar)BookTicket(){
	fmt.Printf("%s---->订票\n",this.Name)
}

//唱歌
func (this *RealStar)Sing(){
	fmt.Printf("%s---->唱歌\n",this.Name)
}

//收钱地
func (this *RealStar)CollectMoney(){
	fmt.Printf("%s---->收钱\n",this.Name)
}


type Proxy struct {
	Name string
	star Star
}


func NewProxy(name string,star Star) Star  {
	return &Proxy{Name: name,star: star}
}



//面谈
func (this *Proxy)Confer(){
	fmt.Printf("%s---->面谈\n",this.Name)
}

//签合同
func (this *Proxy)SignContract(){
	fmt.Printf("%s---->签合同\n",this.Name)
}

//订票
func (this *Proxy)BookTicket(){
	fmt.Printf("%s---->订票\n",this.Name)
}

//唱歌
func (this *Proxy)Sing(){
	this.star.Sing()
}

//收钱地
func (this *Proxy)CollectMoney(){
	fmt.Printf("%s---->收钱\n",this.Name)
}
