package staticProxy

import(
	"testing"
)

func Test_Proxy(t *testing.T){

	star := NewRealStar("周杰伦")
	proxy := NewProxy("A代理",star);

	proxy.Confer()
	proxy.SignContract()
	proxy.BookTicket()
	proxy.Sing()
	proxy.CollectMoney()

}
