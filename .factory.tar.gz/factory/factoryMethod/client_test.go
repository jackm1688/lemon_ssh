package factoryMethod

import(
	"testing"
)

func TestCaFactory(t *testing.T) {

	var c1 Car = (&AudiFactory{}).CreateCar()
	var c2 Car = (&BydFactory{}).CreateCar()

	c1.Run()
	c2.Run()
}
