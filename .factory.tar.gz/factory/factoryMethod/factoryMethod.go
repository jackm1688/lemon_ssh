package factoryMethod

import "fmt"

type Car interface {
	Run()
}

type AudiCar struct {

}

type BydCar struct {

}

func (this *AudiCar) Run(){
	fmt.Println("Audi is Running")
}

func (this *BydCar) Run(){
	fmt.Println("Byd is Running")
}

//工厂方法接口
type CarFactory interface {
	CreateCar() Car
}

type AudiFactory struct {

}

type BydFactory struct {

}

func (this *AudiFactory) CreateCar() Car {
	return &AudiCar{}
}

func (this *BydFactory) CreateCar() Car{
	return &BydCar{}
}

