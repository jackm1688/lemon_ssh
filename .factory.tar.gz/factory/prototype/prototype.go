package prototype

import "time"

type Lemon struct {
	Name string
	Address string
	CreateTime time.Time
}

func New(name string, address string, time time.Time) *Lemon{
	return &Lemon{
		Name:       name,
		Address:    address,
		CreateTime: time,
	}
}

func (this *Lemon) Clone() *Lemon  {
	return New(this.Name,this.Address,this.CreateTime)
}

type School struct {
	ClassId int
}

func NewSchool(classId int) *School  {
	return  &School{ClassId: classId}
}

func (s *School) Clone() *School{
	return NewSchool(s.ClassId)
}

type Home struct {
	Address string
	phone string
}

func NewHome(address string,phone string) *Home{
	return &Home{
		Address: address,
		phone:   phone,
	}
}

func (h *Home) Clone() *Home  {
	return NewHome(h.Address,h.phone)
}

type Person struct {
	Name string
	Age int
	School *School
	Home *Home
}

func NewPerson(name string,age int,school *School,home *Home) *Person  {
	return &Person{
		Name:   name,
		Age:    age,
		School: school,
		Home:   home,
	}
}

func (p *Person) Clone() *Person{
	return  NewPerson(p.Name,p.Age,p.School.Clone(),p.Home.Clone())
}


