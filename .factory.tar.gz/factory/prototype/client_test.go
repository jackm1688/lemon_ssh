package prototype

import (
	"fmt"
	"testing"
	"time"
)

func TestLemon_Clone(t *testing.T) {

	lemon := New("Tom","gdsz",time.Now())
	fmt.Printf("prototype -> lemon:%#v,  time:%s\n",lemon,lemon.CreateTime.Format("2006-01-02 15:04:05"))

	ln := lemon.Clone()
	fmt.Printf("clone -> lemon:%#v,  time:%s\n",ln,ln.CreateTime.Format("2006-01-02 15:04:05"))

	fmt.Println("chmod time")
	fmt.Printf("prototype ->time:%s\n",lemon.CreateTime.Format("2006-01-02 15:04:05"))

}

func TestPersonClone(t *testing.T)  {

	person := &Person{
		Name:   "Tom",
		Age:    22,
		School: &School{10001},
		Home:   &Home{
			Address: "广东深圳",
			phone:   "15000011000",
		},
	}

	fmt.Printf("\nperson:%#v,school:%#v, home:%#v\n",*person,*person.School,*person.Home)


	p2 := person.Clone()
	fmt.Printf("\nperson:%#v,school:%#v, home:%#v\n",*p2,*p2.School,*p2.Home)

	person.Home.phone= "1860000xxx"
	fmt.Println("修改原型中home中手机号:")
	fmt.Printf("\n克隆中：person:%#v,school:%#v, home:%#v\n",*p2,*p2.School,*p2.Home)
	fmt.Printf("\n原型中: person:%#v,school:%#v, home:%#v\n",*person,*person.School,*person.Home)
}
